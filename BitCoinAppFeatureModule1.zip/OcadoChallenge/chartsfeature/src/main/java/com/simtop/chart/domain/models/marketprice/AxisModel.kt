package com.simtop.chart.domain.models.marketprice

data class AxisModel(
    val date: Long,
    val price: Float
)