package com.simtop.chart.di

import com.simtop.di.FeatureScope
import dagger.Module
import dagger.Provides
import javax.inject.Named
import javax.inject.Singleton

@Module
class UrlModule {

    @Provides
    @FeatureScope
    @Named("baseUrl")
    fun provideBaseUrl(): String {
        return "https://api.blockchain.info/"
    }
}