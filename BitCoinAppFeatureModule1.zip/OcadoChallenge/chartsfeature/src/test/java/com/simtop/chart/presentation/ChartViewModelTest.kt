package com.simtop.chart.presentation

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.simtop.chart.presentation.chart.ChartViewState
import com.simtop.chart.presentation.chart.ChartViewModel
import com.simtop.chart.domain.usecases.GetMarketPriceUseCase
import com.simtop.testutils.core.getValueForTest
import com.simtop.chart.utils.fakeMarketPriceModel
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import io.reactivex.Single
import org.amshove.kluent.shouldBeEqualTo
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestRule

internal class ChartViewModelTest {

    @get:Rule
    var rule: TestRule = InstantTaskExecutorRule()

    private val getMarketPriceUseCase: GetMarketPriceUseCase = mockk()

    private val chartViewModel: ChartViewModel by lazy {
        ChartViewModel(getMarketPriceUseCase)
    }

    @Test
    fun `when we get market model it succeeds and shows loader`() {

        coEvery { getMarketPriceUseCase.execute(any()) } returns Single.just(
            fakeMarketPriceModel
        )

        chartViewModel.getMarketPrice()

        chartViewModel.chartViewState.getValueForTest() shouldBeEqualTo ChartViewState.Loading

        Thread.sleep(1000)

        coVerify(exactly = 1) {
            getMarketPriceUseCase.execute(any())
        }

        val response = chartViewModel.chartViewState.getValueForTest()

        if (response is ChartViewState.Success) {
            response.result shouldBeEqualTo fakeMarketPriceModel
        }
    }

    @Test
    fun `when we get market price model it fails and shows error`() {

        coEvery { getMarketPriceUseCase.execute(any()) } returns Single.error(
            Exception("Error getting list of categories")
        )

        chartViewModel.getMarketPrice()

        chartViewModel.chartViewState.getValueForTest() shouldBeEqualTo ChartViewState.Loading

        Thread.sleep(1000)

        coVerify(exactly = 1) {
            getMarketPriceUseCase.execute(any())
        }

        val response = chartViewModel.chartViewState.getValueForTest()

        if (response is ChartViewState.Error) {
            response.result.message shouldBeEqualTo "Error getting list of categories"
        }
    }
}
