import androidx.fragment.app.testing.launchFragmentInContainer
import com.simtop.chart.presentation.chart.ChartFragment
import org.junit.Test

class ChartFragmentTest {

    @Test
    fun fragmentTest() {
        //launchFragmentInContainer<ChartFragment>()

    }
}