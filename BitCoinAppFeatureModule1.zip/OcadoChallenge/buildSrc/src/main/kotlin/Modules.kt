object Modules {
    const val app = ":app"
    const val core = ":core"
    const val chartsfeature = ":chartsfeature"
    const val test_utils = ":testutils"
}