package com.simtop.bitcoinapp.di

import com.simtop.BitCoinAppApplication
import okhttp3.mockwebserver.MockWebServer

class TestApplication : BitCoinAppApplication() {

    lateinit var mockWebServer: MockWebServer

    override fun buildApiComponent() {
        mockWebServer = MockWebServer()
        appComponent = DaggerTestApplicationComponent.factory()
            .create(this)
    }
}